#include "main.h"

void handle_login(client_t *client);
void handle_signup(client_t *client);
void receive_online_users(client_t *client);
void chat_menu(client_t *client);
void single_chat(client_t *client);
void group_chat(client_t *client);
void *listen_server(void *arg);

char current_user[30];
int global_sockfd;

void client_crash_handler(int sig)
{
    printf(ANSI_COLOR_RED "\n[System] : Client exiting due to interrupt signal.\n" ANSI_COLOR_RESET);
    userInfo logout_user;
    memset(&logout_user, 0, sizeof(logout_user));
    logout_user.option = LOGOUT;
    send(global_sockfd, &logout_user, sizeof(logout_user), 0);
    close(global_sockfd);
    exit(0);
}

void *listen_server(void *arg)
{
    int sockfd = *(int *)arg;
    free(arg);
    while (1)
    {
        char buffer[1024];
        int n = recv(sockfd, buffer, sizeof(buffer), 0);
        if (n <= 0)
        {
            printf(ANSI_COLOR_RED "\n[System] : Server disconnected.\n" ANSI_COLOR_RESET);
            close(sockfd);
            raise(SIGKILL);
            return NULL;
        }
        if (n == sizeof(online_packet))
        {
            online_packet *packet = (online_packet *)buffer;
            switch (packet->type)
            {
            case PACKET_JOIN:
                printf(ANSI_COLOR_YELLOW "\n[Notification] : User %s is ONLINE\n" ANSI_COLOR_RESET, packet->name);
                break;
            case PACKET_LEAVE:
                printf(ANSI_COLOR_YELLOW "\n[Notification] : User %s is OFFLINE\n" ANSI_COLOR_RESET, packet->name);
                break;
            // case PACKET_LIST:
            //     printf(ANSI_COLOR_CYAN "[Info] : User %s is Online\n" ANSI_COLOR_RESET, packet->name);
            //     break;
            default:
                printf(ANSI_COLOR_RED "Unknown online packet received\n" ANSI_COLOR_RESET);
                break;
            }
        }
        else if (n == sizeof(userInfo))
        {
            userInfo *msg = (userInfo *)buffer;
            switch (msg->option)
            {
            case SINGLE_CHAT:
                printf(ANSI_COLOR_GREEN "\n[Private] %s : %s" ANSI_COLOR_RESET, msg->username, msg->message);
                break;
            case GROUP_CHAT:
                printf(ANSI_COLOR_MAGENTA "\n[Group] %s : %s" ANSI_COLOR_RESET, msg->username, msg->message);
                break;
            case LOGOUT:
                printf(ANSI_COLOR_YELLOW "\n[Notification] : User %s has logged out.\n" ANSI_COLOR_RESET, msg->username);
                break;
            default:
                printf(ANSI_COLOR_RED "Unknown chat packet received\n" ANSI_COLOR_RESET);
                break;
            }
        }
        fflush(stdout);
    }
    return NULL;
}

int main()
{
    client_t client;
    userInfo new_user;
    status_t response;

    printf(ANSI_COLOR_YELLOW "\n=========================================\n" ANSI_COLOR_RESET);
    printf(ANSI_COLOR_CYAN "      MULTI-CLIENT TCP/IP CHAT ROOM\n" ANSI_COLOR_RESET);
    printf(ANSI_COLOR_YELLOW "=========================================\n" ANSI_COLOR_RESET);

    // Create socket
    client.sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (client.sockfd < 0)
    {
        perror("socket");
        exit(1);
    }

    // Server address
    client.server_addr.sin_family = AF_INET;
    client.server_addr.sin_port = htons(SERVER_PORT);
    client.server_addr.sin_addr.s_addr = inet_addr(SERVER_IP_ADDRESS);

    // Connect
    if (connect(client.sockfd, (struct sockaddr *)&client.server_addr, sizeof(client.server_addr)) != 0)
    {
        perror("connect");
        close(client.sockfd);
        exit(1);
    }
    printf(ANSI_COLOR_MAGENTA "\n[System] : Connected to Chat Room Server.\n" ANSI_COLOR_RESET);
    global_sockfd = client.sockfd; // signal handler can access and close the client socket

    signal(SIGINT, client_crash_handler);  // Ctrl + C
    signal(SIGTSTP, client_crash_handler); // Ctrl + Z

    while (1)
    {
        int choice;
        printf("\n1. Login\n2. Sign-Up\nEnter your choice : ");
        scanf("%d", &choice);
        if (choice == 1)
            handle_login(&client);
        else if (choice == 2)
            handle_signup(&client);
        else
            printf(ANSI_COLOR_RED "Invalid choice!\n" ANSI_COLOR_RESET);
    }
    return 0;
}

void handle_login(client_t *client)
{
    userInfo new_user;
    status_t response;
    new_user.option = LOGIN;
    printf(ANSI_COLOR_BLUE "Enter username : " ANSI_COLOR_RESET);
    scanf("%s", new_user.username);
    printf(ANSI_COLOR_BLUE "Enter password : " ANSI_COLOR_RESET);
    scanf("%s", new_user.password);
    send(client->sockfd, &new_user, sizeof(new_user), 0);
    if (recv(client->sockfd, &response, sizeof(response), 0) <= 0)
    {
        printf(ANSI_COLOR_RED "Server disconnected\n" ANSI_COLOR_RESET);
        exit(0);
    }
    if (response == LOGIN_SUCCESS)
    {
        printf(ANSI_COLOR_GREEN "Login Successful!\n" ANSI_COLOR_RESET);
        strcpy(current_user, new_user.username);
        receive_online_users(client);
        pthread_t tid;
        int *sock_ptr = malloc(sizeof(int));
        *sock_ptr = client->sockfd;
        pthread_create(&tid, NULL, listen_server, sock_ptr);
        chat_menu(client);
    }
    else if (response == USERNAME_NOT_FOUND)
    {
        printf(ANSI_COLOR_RED "Username not found!\n" ANSI_COLOR_RESET);
    }
    else if (response == WRONG_PASSWORD)
    {
        printf(ANSI_COLOR_RED "Wrong password!\n" ANSI_COLOR_RESET);
    }
    else
    {
        printf(ANSI_COLOR_RED "Login failed!\n" ANSI_COLOR_RESET);
    }
}

void handle_signup(client_t *client)
{
    userInfo new_user;
    status_t response;
    new_user.option = SIGNUP;
    printf(ANSI_COLOR_BLUE "Enter username : " ANSI_COLOR_RESET);
    scanf("%s", new_user.username);
    printf(ANSI_COLOR_BLUE "Enter password : " ANSI_COLOR_RESET);
    scanf("%s", new_user.password);
    send(client->sockfd, &new_user, sizeof(new_user), 0);
    if (recv(client->sockfd, &response, sizeof(response), 0) <= 0)
    {
        printf(ANSI_COLOR_RED "Server disconnected\n" ANSI_COLOR_RESET);
        exit(0);
    }
    if (response == SIGNUP_SUCCESS)
        printf(ANSI_COLOR_GREEN "Signup Successful!\n" ANSI_COLOR_RESET);
    else if (response == USER_ALREADY_EXISTS)
        printf(ANSI_COLOR_RED "User already exists!\n" ANSI_COLOR_RESET);
    else
        printf(ANSI_COLOR_RED "Signup Failed!\n" ANSI_COLOR_RESET);
}

void receive_online_users(client_t *client)
{
    online_packet packet;
    printf(ANSI_COLOR_CYAN "\n========= Online Users =========\n" ANSI_COLOR_RESET);
    while (1)
    {
        if (recv(client->sockfd, &packet, sizeof(packet), 0) <= 0)
        {
            printf(ANSI_COLOR_RED "Server disconnected\n" ANSI_COLOR_RESET);
            exit(0);
        }
        if (packet.stop == 1)
            break;
        if (packet.type == PACKET_LIST)
        {
            printf(ANSI_COLOR_YELLOW "[Info] : User %s is Online\n" ANSI_COLOR_RESET, packet.name);
        }
    }
}

void chat_menu(client_t *client)
{
    while (1)
    {
        int chat_choice;
        printf("\n1. Single Chat");
        printf("\n2. Group Chat");
        printf("\n3. Logout\n");
        printf("Enter your choice: ");
        scanf("%d", &chat_choice);
        if (chat_choice == 1)
        {
            single_chat(client);
        }
        else if (chat_choice == 2)
        {
            group_chat(client);
        }
        else if (chat_choice == 3)
        {
            userInfo logout_user;
            logout_user.option = LOGOUT;
            send(client->sockfd, &logout_user, sizeof(logout_user), 0);
            printf(ANSI_COLOR_GREEN "\n[System] : You have logged out successfully.\n" ANSI_COLOR_RESET);
            close(client->sockfd);
            exit(0);
        }
        else
        {
            printf(ANSI_COLOR_RED "Invalid choice\n" ANSI_COLOR_RESET);
        }
    }
}
void single_chat(client_t *client)
{
    userInfo new_user;
    memset(&new_user, 0, sizeof(new_user));
    new_user.option = SINGLE_CHAT;
    strcpy(new_user.username, current_user);
    printf("Enter username to chat with: ");
    scanf("%s", new_user.target);
    printf("Enter message: ");
    scanf(" %[^\n]", new_user.message);
    send(client->sockfd, &new_user, sizeof(new_user), 0);
}
void group_chat(client_t *client)
{
    userInfo new_user;
    memset(&new_user, 0, sizeof(new_user));
    new_user.option = GROUP_CHAT;
    strcpy(new_user.username, current_user);
    strcpy(new_user.target, "GROUP");
    printf("Enter group message: ");
    scanf(" %[^\n]", new_user.message);
    send(client->sockfd, &new_user, sizeof(new_user), 0);
}